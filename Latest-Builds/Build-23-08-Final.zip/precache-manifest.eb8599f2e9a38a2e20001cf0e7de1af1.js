self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "585f040d225b31cf83e7d19fce4916ba",
    "url": "/index.html"
  },
  {
    "revision": "23826f2d510cdaa85586",
    "url": "/static/css/main.1e1938c9.chunk.css"
  },
  {
    "revision": "fc5e4c4786a06ed8a9d5",
    "url": "/static/js/2.f370d538.chunk.js"
  },
  {
    "revision": "6c99299aa0ccf7cd363681b2638ef8ef",
    "url": "/static/js/2.f370d538.chunk.js.LICENSE.txt"
  },
  {
    "revision": "23826f2d510cdaa85586",
    "url": "/static/js/main.b911a906.chunk.js"
  },
  {
    "revision": "f6514ec09f782dcc75a7",
    "url": "/static/js/runtime-main.f241de88.js"
  },
  {
    "revision": "329bef2a65698f61594e3e3d40f7db66",
    "url": "/static/media/1.329bef2a.jpg"
  },
  {
    "revision": "54a99bf4819f0114c24c7e3cfdf4923e",
    "url": "/static/media/1.54a99bf4.jpg"
  },
  {
    "revision": "5d2d50eea13bc59fcb8bb0abc3fbfad7",
    "url": "/static/media/1.5d2d50ee.jpg"
  },
  {
    "revision": "871b655c5e521607cf8e1b75c596ec7b",
    "url": "/static/media/1.871b655c.jpg"
  },
  {
    "revision": "98c4c780034745034006bff5a0202a76",
    "url": "/static/media/1.98c4c780.jpg"
  },
  {
    "revision": "9ce03a298b942435c5d53d9b2574fb3a",
    "url": "/static/media/10.9ce03a29.jpg"
  },
  {
    "revision": "c697c900ae8d53d4614cedccd4f1d371",
    "url": "/static/media/10.c697c900.jpg"
  },
  {
    "revision": "e8962d8bf1bb1ddf3128980dfdceebbf",
    "url": "/static/media/10.e8962d8b.jpg"
  },
  {
    "revision": "881730e906b03446bee720ecdf4abfab",
    "url": "/static/media/11.881730e9.jpg"
  },
  {
    "revision": "8aa0a61ebeb66fa16ce39afe092258af",
    "url": "/static/media/11.8aa0a61e.jpg"
  },
  {
    "revision": "8c4970a20f7cf0aa0e25c2ddd02495b0",
    "url": "/static/media/11.8c4970a2.jpg"
  },
  {
    "revision": "f3e999c7e536e1129d9e756e1d00483f",
    "url": "/static/media/12.f3e999c7.jpg"
  },
  {
    "revision": "ecc4ec565faa54635d1dd7ec0821639d",
    "url": "/static/media/13.ecc4ec56.jpg"
  },
  {
    "revision": "2e853899aa59c6b0e5574759d3d2802f",
    "url": "/static/media/14.2e853899.jpg"
  },
  {
    "revision": "7de5196d50eb15f2e484ce76ebd7153d",
    "url": "/static/media/15.7de5196d.jpg"
  },
  {
    "revision": "25a76121ae51fbb2b236f9ee0f11738e",
    "url": "/static/media/16.25a76121.jpg"
  },
  {
    "revision": "a1ed21a489609bbc6ee38e8249064a04",
    "url": "/static/media/17.a1ed21a4.jpg"
  },
  {
    "revision": "d17db65b7a7f70b7a12a62378f98bc8c",
    "url": "/static/media/18.d17db65b.jpg"
  },
  {
    "revision": "9a62195dd78ab9146e8eb615cbf89bb8",
    "url": "/static/media/19.9a62195d.jpg"
  },
  {
    "revision": "309b2a5aa2f1cbf0c192a3afcde8f05a",
    "url": "/static/media/1L.309b2a5a.jpg"
  },
  {
    "revision": "31564cade6182d6e1bb317213db2d8f1",
    "url": "/static/media/1L.31564cad.jpg"
  },
  {
    "revision": "3bf54e39fcbd65af16789cff6d48b2ee",
    "url": "/static/media/1X.3bf54e39.png"
  },
  {
    "revision": "9408afa5058a82aae40db4b6e35e3e04",
    "url": "/static/media/2.9408afa5.jpg"
  },
  {
    "revision": "9f0abe82b8c6e77710c6c6d8267c7437",
    "url": "/static/media/2.9f0abe82.jpg"
  },
  {
    "revision": "4e6ca1e90dc498648c864ee9dfe1f359",
    "url": "/static/media/2L.4e6ca1e9.jpg"
  },
  {
    "revision": "a103c5e1fb926ff56eb0d87475e05994",
    "url": "/static/media/2L.a103c5e1.jpg"
  },
  {
    "revision": "fea57fa3be4db811fdc0044e9b000db6",
    "url": "/static/media/2X.fea57fa3.png"
  },
  {
    "revision": "051b80ac904abb114edc225ef2103e6c",
    "url": "/static/media/3.051b80ac.jpg"
  },
  {
    "revision": "0994165deb750ac462d0f6029c8d9e62",
    "url": "/static/media/3.0994165d.jpg"
  },
  {
    "revision": "3e31b37d49dc576b5e6cc1d117a490af",
    "url": "/static/media/3.3e31b37d.jpg"
  },
  {
    "revision": "980514335f5e23effd05f1b20a8111ba",
    "url": "/static/media/3.98051433.jpg"
  },
  {
    "revision": "3e64cc204441ff71c04808e7a2f09b1c",
    "url": "/static/media/3L.3e64cc20.jpg"
  },
  {
    "revision": "ff5ca798a7b1194955bd3e10715eeaf4",
    "url": "/static/media/3L.ff5ca798.jpg"
  },
  {
    "revision": "1cf976d77c5de40ba1da92101aee7fff",
    "url": "/static/media/4.1cf976d7.jpg"
  },
  {
    "revision": "9bdc941816bcc1f3f3d9d6619bde5f3e",
    "url": "/static/media/4.9bdc9418.jpg"
  },
  {
    "revision": "e73f2b07c5bbe321d3f06e18c5b644be",
    "url": "/static/media/4.e73f2b07.jpg"
  },
  {
    "revision": "eac550fed26a8bb5ffa7d5e9211c76f9",
    "url": "/static/media/4.eac550fe.jpg"
  },
  {
    "revision": "84cd359139ca1d8f72f6d9019c1ef707",
    "url": "/static/media/4L.84cd3591.jpg"
  },
  {
    "revision": "dc1d7868bba92c215e43bb8806be1aa4",
    "url": "/static/media/4L.dc1d7868.jpg"
  },
  {
    "revision": "a599bb7f279d7356992e19a874aeb6f6",
    "url": "/static/media/4X.a599bb7f.png"
  },
  {
    "revision": "80adf1dc7a391eab11d073f67000a3df",
    "url": "/static/media/5.80adf1dc.jpg"
  },
  {
    "revision": "e68f529aa1b6dc3c665e5ba51d3f6b39",
    "url": "/static/media/5.e68f529a.jpg"
  },
  {
    "revision": "3b9f0d4a7fe431e9cd018587ce8f4102",
    "url": "/static/media/6.3b9f0d4a.jpg"
  },
  {
    "revision": "a806f1a86fcdb59a1a5c80fb535d70cb",
    "url": "/static/media/6.a806f1a8.jpg"
  },
  {
    "revision": "0786be3daf65eb3ebed446f9f3adf7c3",
    "url": "/static/media/7.0786be3d.jpg"
  },
  {
    "revision": "5346c7ca92410c3e632f5b66ad60d5e4",
    "url": "/static/media/7.5346c7ca.jpg"
  },
  {
    "revision": "c658521d5b3f91832ce781298b259559",
    "url": "/static/media/7.c658521d.jpg"
  },
  {
    "revision": "424ef0c1ef4ab653659a9ce35dcc0ffc",
    "url": "/static/media/8.424ef0c1.jpg"
  },
  {
    "revision": "cf8140ac405356f284157cb6590a8ecc",
    "url": "/static/media/8.cf8140ac.jpg"
  },
  {
    "revision": "d9fe7e253c97986be7db5a06eca013c5",
    "url": "/static/media/8.d9fe7e25.jpg"
  },
  {
    "revision": "206b718dc21455063de3c9e8a176793c",
    "url": "/static/media/9.206b718d.jpg"
  },
  {
    "revision": "5285b0e87ead292abb1cb4f3e6c52d59",
    "url": "/static/media/9.5285b0e8.jpg"
  },
  {
    "revision": "f21acbd1eefe9522f257c118ad36c90c",
    "url": "/static/media/9.f21acbd1.jpg"
  },
  {
    "revision": "ce12cb2711168854753ee44be3fd0b78",
    "url": "/static/media/AboutUs-Main-3.ce12cb27.jpg"
  },
  {
    "revision": "f06dfcf1e6acd0b649261e885d663003",
    "url": "/static/media/AboutUs.f06dfcf1.jpg"
  },
  {
    "revision": "d4e865e1fcd749ffbd48a65dff682e26",
    "url": "/static/media/Adi.d4e865e1.jpg"
  },
  {
    "revision": "ef99f346545228c7b5310e0504f81020",
    "url": "/static/media/Amar.ef99f346.jpg"
  },
  {
    "revision": "b41f59eb6cfd7895e325ca64bac989fc",
    "url": "/static/media/Anirudh.b41f59eb.jpg"
  },
  {
    "revision": "2a4dd423d656067c9756decbf8f22b92",
    "url": "/static/media/Author-LBTC-L.2a4dd423.png"
  },
  {
    "revision": "e5f967ebf876f2d3377da9f58f4b643c",
    "url": "/static/media/Avinash.e5f967eb.jpg"
  },
  {
    "revision": "ea7a14d6864896595de350d2933521f0",
    "url": "/static/media/Bhuvan.ea7a14d6.jpg"
  },
  {
    "revision": "c11cb2e95f3e39ac669012004595fe57",
    "url": "/static/media/Blog1.c11cb2e9.jpg"
  },
  {
    "revision": "21f3221a1faf4f090e5a69107b9304e4",
    "url": "/static/media/Blog2.21f3221a.jpg"
  },
  {
    "revision": "f6f9cabd3b49e195d974419f3ee3aed5",
    "url": "/static/media/Blog3.f6f9cabd.jpg"
  },
  {
    "revision": "38ef752afc98d1c1c8c5fc7f0744aeb7",
    "url": "/static/media/Blog4.38ef752a.jpg"
  },
  {
    "revision": "ce690b2ccd3cbdf9f0dfa6567cf49246",
    "url": "/static/media/Blog5.ce690b2c.jpg"
  },
  {
    "revision": "dfbb9d0f6b4be2d6c485d32a56b9442a",
    "url": "/static/media/Blog6.dfbb9d0f.jpg"
  },
  {
    "revision": "5ec62a1e2e3abcc868c154748f8bdcd0",
    "url": "/static/media/Blog7.5ec62a1e.jpg"
  },
  {
    "revision": "fc0e232e0f69598f8546af9911aecc7e",
    "url": "/static/media/Carousel-W.fc0e232e.png"
  },
  {
    "revision": "a1b04dc6a56cea536e95ed39505a927c",
    "url": "/static/media/Come2OurEventsX.a1b04dc6.jpg"
  },
  {
    "revision": "680941349dd17cbb56ad683c3ced72ab",
    "url": "/static/media/CoreTeam.68094134.JPG"
  },
  {
    "revision": "1a6468c926fbc3e0236a03645044bd2d",
    "url": "/static/media/EarlyBird.1a6468c9.otf"
  },
  {
    "revision": "4b988ebcb200554e671dd3b310aa806a",
    "url": "/static/media/Entreaty.4b988ebc.ttf"
  },
  {
    "revision": "0625eeaeea992dee31aa450b7f261cb2",
    "url": "/static/media/Flaticon.0625eeae.woff2"
  },
  {
    "revision": "260d2293abc6355110d7a11442a5e712",
    "url": "/static/media/Flaticon.260d2293.woff"
  },
  {
    "revision": "43ed6edff5664e2c3776710044187a75",
    "url": "/static/media/Flaticon.43ed6edf.eot"
  },
  {
    "revision": "7ff5ddf4bbda29bc179a8583ceb72cc2",
    "url": "/static/media/Flaticon.7ff5ddf4.ttf"
  },
  {
    "revision": "abc969db93cb5a8074d95858eaebba9a",
    "url": "/static/media/Flaticon.abc969db.svg"
  },
  {
    "revision": "cedf22c228d2ce6ffee71989acdf4b06",
    "url": "/static/media/Hemanth.cedf22c2.jpg"
  },
  {
    "revision": "81d4db6cde4da4c4935d0cdadcee9cbd",
    "url": "/static/media/JoinUs.81d4db6c.jpg"
  },
  {
    "revision": "cad67f51ea435ebbadf7e5e07a01fae1",
    "url": "/static/media/Karthik.cad67f51.jpg"
  },
  {
    "revision": "ba985fbc2062da4d0b81d6fc6f5195b2",
    "url": "/static/media/LBTC-Footer-Logo-C.ba985fbc.png"
  },
  {
    "revision": "ba985fbc2062da4d0b81d6fc6f5195b2",
    "url": "/static/media/LBTC-Footer-Logo-W.ba985fbc.png"
  },
  {
    "revision": "9b0b4bbc2f4f3f9a3f7c62e82ce6b338",
    "url": "/static/media/LBTC-Header-Logo-CS.9b0b4bbc.png"
  },
  {
    "revision": "e85c42ef8be3a09d751ba072bff87382",
    "url": "/static/media/Logo.e85c42ef.png"
  },
  {
    "revision": "318cbd9d4d23097d35e58621fa6485d8",
    "url": "/static/media/Lohit.318cbd9d.jpg"
  },
  {
    "revision": "8341ccd2d303c66b6ba7801d59c4b149",
    "url": "/static/media/Nidish.8341ccd2.jpg"
  },
  {
    "revision": "2dde2eac44fb8be4705f65418dda0158",
    "url": "/static/media/Niranjan.2dde2eac.jpg"
  },
  {
    "revision": "01798bc13e33afc36a52f2826638d386",
    "url": "/static/media/Pe-icon-7-stroke.01798bc1.ttf"
  },
  {
    "revision": "71394c0c7ad6c1e7d5c77e8ac292fba5",
    "url": "/static/media/Pe-icon-7-stroke.71394c0c.eot"
  },
  {
    "revision": "b38ef310874bdd008ac14ef3db939032",
    "url": "/static/media/Pe-icon-7-stroke.b38ef310.woff"
  },
  {
    "revision": "dedf26989fdd78c33cb9ae664a604d6c",
    "url": "/static/media/Pe-icon-7-stroke.dedf2698.svg"
  },
  {
    "revision": "97f98b6fb157ed85ff6084421bf25b4c",
    "url": "/static/media/Prajwal.97f98b6f.jpg"
  },
  {
    "revision": "2a654509ea9bdcad1d2319ef73f774c6",
    "url": "/static/media/Rahul.2a654509.jpg"
  },
  {
    "revision": "ba8c5f8f08d6a1f1e056da25a3c8aef1",
    "url": "/static/media/Sahiti.ba8c5f8f.jpg"
  },
  {
    "revision": "7bc6d73c5920df56ae1eff5cdf99650c",
    "url": "/static/media/Sharan.7bc6d73c.jpg"
  },
  {
    "revision": "e66e0a3d3710056032c6bc4fe026465f",
    "url": "/static/media/Srinidhi.e66e0a3d.jpg"
  },
  {
    "revision": "ccc3be53e32df4abc3e43a0080b4ab03",
    "url": "/static/media/Vatsa.ccc3be53.jpg"
  },
  {
    "revision": "d5f01b6e2f14aa44c8c307378e006d36",
    "url": "/static/media/VideoBkgnd.d5f01b6e.jpg"
  },
  {
    "revision": "3f60d99ad56f1d7debcb7071b8520e05",
    "url": "/static/media/Vinay.3f60d99a.jpg"
  },
  {
    "revision": "06dbc2c8431f9fe2a791d6147e76e104",
    "url": "/static/media/Vyshak.06dbc2c8.jpg"
  },
  {
    "revision": "5b3fe687c1c1dde88cb61f8ae7ae727e",
    "url": "/static/media/WWR.5b3fe687.jpg"
  },
  {
    "revision": "1a78d4716f2753c662b0265eae12cf41",
    "url": "/static/media/What-Do-WeDo.1a78d471.jpg"
  },
  {
    "revision": "9f27d8fb0ac7f355882c3f41cb796dc9",
    "url": "/static/media/Who-AreWe.9f27d8fb.jpg"
  },
  {
    "revision": "fc155cb8b6f777d8c7e0e911604f6a2c",
    "url": "/static/media/X10X.fc155cb8.png"
  },
  {
    "revision": "be2023d9e807bb66edb17e36b10c0ad4",
    "url": "/static/media/Yoshita.be2023d9.jpg"
  },
  {
    "revision": "674f50d287a8c48dc19ba404d20fe713",
    "url": "/static/media/fontawesome-webfont.674f50d2.eot"
  },
  {
    "revision": "acf3dcb7ff752b5296ca23ba2c7c2606",
    "url": "/static/media/fontawesome-webfont.acf3dcb7.svg"
  },
  {
    "revision": "af7ae505a9eed503f8b8e6982036873e",
    "url": "/static/media/fontawesome-webfont.af7ae505.woff2"
  },
  {
    "revision": "b06871f281fee6b241d60582ae9369b9",
    "url": "/static/media/fontawesome-webfont.b06871f2.ttf"
  },
  {
    "revision": "fee66e712a8a08eef5805a46892932ad",
    "url": "/static/media/fontawesome-webfont.fee66e71.woff"
  },
  {
    "revision": "8282f7a7d15b4ba3b4b213fc740fc442",
    "url": "/static/media/kannada-logo.8282f7a7.png"
  },
  {
    "revision": "48fd3b8e18e15ec4c21d429f0e3f3fd5",
    "url": "/static/media/lbtc-allergan.48fd3b8e.png"
  },
  {
    "revision": "ed65bedd7a1902f9233e816b4bb6ece7",
    "url": "/static/media/lbtc-bbn.ed65bedd.png"
  },
  {
    "revision": "7ac3e8ced432e848c34dc93617fc7ee5",
    "url": "/static/media/lbtc-bengalore-chronicles-logo.7ac3e8ce.png"
  },
  {
    "revision": "d0678a5fc106fd1287b386fe87a11699",
    "url": "/static/media/lbtc-better-india-logo.d0678a5f.png"
  },
  {
    "revision": "f1303fd1250c41baa163e566a238c135",
    "url": "/static/media/lbtc-britannia.f1303fd1.png"
  },
  {
    "revision": "6c6e6c78d074212313f7301ffeef72bc",
    "url": "/static/media/lbtc-dell.6c6e6c78.png"
  },
  {
    "revision": "af29265dc08e2e02557c91811963b6b5",
    "url": "/static/media/lbtc-infosys.af29265d.png"
  },
  {
    "revision": "f6d9b61aecc07708c951dc7454d6982d",
    "url": "/static/media/lbtc-jyoti.f6d9b61a.png"
  },
  {
    "revision": "7a847221bd57beabc59b5e50bb4043ef",
    "url": "/static/media/lbtc-kannada-prabha-logo.7a847221.png"
  },
  {
    "revision": "2e0b80ca83c46d35f41341fe829e7092",
    "url": "/static/media/lbtc-prajavani-logo.2e0b80ca.png"
  },
  {
    "revision": "9d98efb6f9160150a6c5dc40cc65a97e",
    "url": "/static/media/lbtc-st-jhones.9d98efb6.png"
  },
  {
    "revision": "dfed24f58e0fed8c2e1aa88b109697ec",
    "url": "/static/media/lbtc-toi-logo.dfed24f5.png"
  },
  {
    "revision": "c3098cdf98b2b3fc76e7236e69969238",
    "url": "/static/media/lbtc-vijay-karnataka.c3098cdf.png"
  },
  {
    "revision": "0d8050937c004709fb2d20bca6f334fa",
    "url": "/static/media/lbtc-your-story.0d805093.png"
  },
  {
    "revision": "ee7cd8ed2dcec943251eb2763684fc6f",
    "url": "/static/media/logo.ee7cd8ed.svg"
  },
  {
    "revision": "f04386034cc9de663f128020ef76f9ff",
    "url": "/static/media/pattern-bg1.f0438603.jpg"
  }
]);