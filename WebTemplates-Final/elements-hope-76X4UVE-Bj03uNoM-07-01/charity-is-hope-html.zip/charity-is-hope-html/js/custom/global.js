	window._wpemojiSettings = {
		"baseUrl": "https:\/\/s.w.org\/images\/core\/emoji\/2\/72x72\/",
		"ext": ".png",
		"svgUrl": "https:\/\/s.w.org\/images\/core\/emoji\/2\/svg\/",
		"svgExt": ".svg",
		"source": {
			"concatemoji": "http:\/\/charity-is-hope.themerex.net\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.6.1"
		}
	};
	! function(a, b, c) {
		function d(a) {
			var c, d, e, f, g, h = b.createElement("canvas"),
				i = h.getContext && h.getContext("2d"),
				j = String.fromCharCode;
			if (!i || !i.fillText) return !1;
			switch (i.textBaseline = "top", i.font = "600 32px Arial", a) {
				case "flag":
					return i.fillText(j(55356, 56806, 55356, 56826), 0, 0), !(h.toDataURL().length < 3e3) && (i.clearRect(0, 0, h.width, h.height), i.fillText(j(55356, 57331, 65039, 8205, 55356, 57096), 0, 0), c = h.toDataURL(), i.clearRect(0, 0, h.width, h.height),
						i.fillText(j(55356, 57331, 55356, 57096), 0, 0), d = h.toDataURL(), c !== d);
				case "diversity":
					return i.fillText(j(55356, 57221), 0, 0), e = i.getImageData(16, 16, 1, 1).data, f = e[0] + "," + e[1] + "," + e[2] + "," + e[3], i.fillText(j(55356, 57221, 55356, 57343), 0, 0), e = i.getImageData(16, 16, 1, 1).data, g = e[0] + "," + e[1] +
						"," + e[2] + "," + e[3], f !== g;
				case "simple":
					return i.fillText(j(55357, 56835), 0, 0), 0 !== i.getImageData(16, 16, 1, 1).data[0];
				case "unicode8":
					return i.fillText(j(55356, 57135), 0, 0), 0 !== i.getImageData(16, 16, 1, 1).data[0];
				case "unicode9":
					return i.fillText(j(55358, 56631), 0, 0), 0 !== i.getImageData(16, 16, 1, 1).data[0]
			}
			return !1
		}

		function e(a) {
			var c = b.createElement("script");
			c.src = a, c.type = "text/javascript", b.getElementsByTagName("head")[0].appendChild(c)
		}
		var f, g, h, i;
		for (i = Array("simple", "flag", "unicode8", "diversity", "unicode9"), c.supports = {
				everything: !0,
				everythingExceptFlag: !0
			}, h = 0; h < i.length; h++) c.supports[i[h]] = d(i[h]), c.supports.everything = c.supports.everything && c.supports[i[h]], "flag" !== i[h] && (c.supports.everythingExceptFlag = c.supports.everythingExceptFlag && c.supports[i[h]]);
		c.supports.everythingExceptFlag = c.supports.everythingExceptFlag && !c.supports.flag, c.DOMReady = !1, c.readyCallback = function() {
			c.DOMReady = !0
		}, c.supports.everything || (g = function() {
			c.readyCallback()
		}, b.addEventListener ? (b.addEventListener("DOMContentLoaded", g, !1), a.addEventListener("load", g, !1)) : (a.attachEvent("onload", g), b.attachEvent("onreadystatechange", function() {
			"complete" === b.readyState && c.readyCallback()
		})), f = c.source || {}, f.concatemoji ? e(f.concatemoji) : f.wpemoji && f.twemoji && (e(f.twemoji), e(f.wpemoji)))
	}(window, document, window._wpemojiSettings);

	/* <![CDATA[ */
	var tribe_events_linked_posts = {
		"post_types": {
			"tribe_venue": "venue",
			"tribe_organizer": "organizer"
		}
	};
	/* ]]> */
	/* <![CDATA[ */
	var wc_add_to_cart_params = {
		"ajax_url": "\/wp-admin\/admin-ajax.php",
		"wc_ajax_url": "\/about-us-style-1\/?wc-ajax=%%endpoint%%",
		"i18n_view_cart": "View Cart",
		"cart_url": "http:\/\/charity-is-hope.themerex.net\/cart\/",
		"is_cart": "",
		"cart_redirect_after_add": "no"
	};
	/* ]]> */
	/* <![CDATA[ */
	var tribe_js_config = {
		"permalink_settings": "\/%postname%\/",
		"events_post_type": "tribe_events",
		"events_base": "http:\/\/charity-is-hope.themerex.net\/events\/"
	};
	/* ]]> */
	/* <![CDATA[ */
	var tribe_bootstrap_datepicker_strings = {
		"dates": {
			"days": ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
			"daysShort": ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
			"daysMin": ["S", "M", "T", "W", "T", "F", "S", "S"],
			"months": ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
			"monthsShort": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
			"clear": "Clear",
			"today": "Today"
		}
	};
	/* ]]> */
	/* <![CDATA[ */
	var mejsL10n = {
		"language": "en-US",
		"strings": {
			"Close": "Close",
			"Fullscreen": "Fullscreen",
			"Turn off Fullscreen": "Turn off Fullscreen",
			"Go Fullscreen": "Go Fullscreen",
			"Download File": "Download File",
			"Download Video": "Download Video",
			"Play": "Play",
			"Pause": "Pause",
			"Captions\/Subtitles": "Captions\/Subtitles",
			"None": "None",
			"Time Slider": "Time Slider",
			"Skip back %1 seconds": "Skip back %1 seconds",
			"Video Player": "Video Player",
			"Audio Player": "Audio Player",
			"Volume Slider": "Volume Slider",
			"Mute Toggle": "Mute Toggle",
			"Unmute": "Unmute",
			"Mute": "Mute",
			"Use Up\/Down Arrow keys to increase or decrease volume.": "Use Up\/Down Arrow keys to increase or decrease volume.",
			"Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds.": "Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds."
		}
	};
	var _wpmejsSettings = {
		"pluginPath": "\/wp-includes\/js\/mediaelement\/"
	};
	/* ]]> */
	/* <![CDATA[ */
	var CHARITY_IS_HOPE_STORAGE = {
		"system_message": {
			"message": "",
			"status": "",
			"header": ""
		},
		"theme_font": "Open Sans",
		"theme_color": "#333333",
		"theme_bg_color": "#ffffff",
		"strings": {
			"ajax_error": "Invalid server answer",
			"bookmark_add": "Add the bookmark",
			"bookmark_added": "Current page has been successfully added to the bookmarks. You can see it in the right panel on the tab &#039;Bookmarks&#039;",
			"bookmark_del": "Delete this bookmark",
			"bookmark_title": "Enter bookmark title",
			"bookmark_exists": "Current page already exists in the bookmarks list",
			"search_error": "Error occurs in AJAX search! Please, type your query and press search icon for the traditional search way.",
			"email_confirm": "On the e-mail address &quot;%s&quot; we sent a confirmation email. Please, open it and click on the link.",
			"reviews_vote": "Thanks for your vote! New average rating is:",
			"reviews_error": "Error saving your vote! Please, try again later.",
			"error_like": "Error saving your like! Please, try again later.",
			"error_global": "Global error text",
			"name_empty": "The name can&#039;t be empty",
			"name_long": "Too long name",
			"email_empty": "Too short (or empty) email address",
			"email_long": "Too long email address",
			"email_not_valid": "Invalid email address",
			"subject_empty": "The subject can&#039;t be empty",
			"subject_long": "Too long subject",
			"text_empty": "The message text can&#039;t be empty",
			"text_long": "Too long message text",
			"send_complete": "Send message complete!",
			"send_error": "Transmit failed!",
			"geocode_error": "Geocode was not successful for the following reason:",
			"googlemap_not_avail": "Google map API not available!",
			"editor_save_success": "Post content saved!",
			"editor_save_error": "Error saving post data!",
			"editor_delete_post": "You really want to delete the current post?",
			"editor_delete_post_header": "Delete post",
			"editor_delete_success": "Post deleted!",
			"editor_delete_error": "Error deleting post!",
			"editor_caption_cancel": "Cancel",
			"editor_caption_close": "Close"
		},
		"ajax_url": "http:\/\/charity-is-hope.themerex.net\/wp-admin\/admin-ajax.php",
		"ajax_nonce": "c40826179b",
		"site_url": "http:\/\/charity-is-hope.themerex.net",
		"site_protocol": "http",
		"vc_edit_mode": "",
		"accent1_color": "#84c54e",
		"accent1_hover": "#ff7e27",
		"slider_height": "100",
		"user_logged_in": "",
		"toc_menu": "hide",
		"toc_menu_home": "",
		"toc_menu_top": "",
		"menu_fixed": "1",
		"menu_mobile": "1024",
		"menu_hover": "fade",
		"button_hover": "default",
		"input_hover": "default",
		"demo_time": "0",
		"media_elements_enabled": "1",
		"ajax_search_enabled": "1",
		"ajax_search_min_length": "3",
		"ajax_search_delay": "200",
		"css_animation": "1",
		"menu_animation_in": "fadeInUpSmall",
		"menu_animation_out": "fadeOutDownSmall",
		"popup_engine": "magnific",
		"email_mask": "^([a-zA-Z0-9_\\-]+\\.)*[a-zA-Z0-9_\\-]+@[a-z0-9_\\-]+(\\.[a-z0-9_\\-]+)*\\.[a-z]{2,6}$",
		"contacts_maxlength": "1000",
		"comments_maxlength": "1000",
		"remember_visitors_settings": "",
		"admin_mode": "",
		"isotope_resize_delta": "0.3",
		"error_message_box": null,
		"viewmore_busy": "",
		"video_resize_inited": "",
		"top_panel_height": "0"
	};
	/* ]]> */
	/* <![CDATA[ */
	var wc_cart_fragments_params = {
		"ajax_url": "\/wp-admin\/admin-ajax.php",
		"wc_ajax_url": "\/video-tutorials\/?wc-ajax=%%endpoint%%",
		"fragment_name": "wc_fragments"
	};
	/* ]]> */
	/* <![CDATA[ */
		var wc_single_product_params = {
			"i18n_required_rating_text": "Please select a rating",
			"review_rating_required": "yes"
		};
		/* ]]> */
	/* <![CDATA[ */
	var TRX_UTILS_STORAGE = {
		"ajax_url": "http:\/\/charity-is-hope.themerex.net\/wp-admin\/admin-ajax.php",
		"ajax_nonce": "c40826179b",
		"site_url": "http:\/\/charity-is-hope.themerex.net",
		"user_logged_in": "0",
		"email_mask": "^([a-zA-Z0-9_\\-]+\\.)*[a-zA-Z0-9_\\-]+@[a-z0-9_\\-]+(\\.[a-z0-9_\\-]+)*\\.[a-z]{2,6}$",
		"msg_ajax_error": "Invalid server answer!",
		"msg_error_global": "Invalid field's value!",
		"msg_name_empty": "The name can't be empty",
		"msg_email_empty": "Too short (or empty) email address",
		"msg_email_not_valid": "E-mail address is invalid",
		"msg_text_empty": "The message text can't be empty",
		"msg_send_complete": "Send message complete!",
		"msg_send_error": "Transmit failed!",
		"login_via_ajax": "1",
		"msg_login_empty": "The Login field can't be empty",
		"msg_login_long": "The Login field is too long",
		"msg_password_empty": "The password can't be empty and shorter then 4 characters",
		"msg_password_long": "The password is too long",
		"msg_login_success": "Login success! The page will be reloaded in 3 sec.",
		"msg_login_error": "Login failed!",
		"msg_not_agree": "Please, read and check 'Terms and Conditions'",
		"msg_email_long": "E-mail address is too long",
		"msg_password_not_equal": "The passwords in both fields are not equal",
		"msg_registration_success": "Registration success! Please log in!",
		"msg_registration_error": "Registration failed!"
	};
	/* ]]> */


	var ajaxRevslider;

	jQuery(document).ready(function() {
		// CUSTOM AJAX CONTENT LOADING FUNCTION
		ajaxRevslider = function(obj) {

			// obj.type : Post Type
			// obj.id : ID of Content to Load
			// obj.aspectratio : The Aspect Ratio of the Container / Media
			// obj.selector : The Container Selector where the Content of Ajax will be injected. It is done via the Essential Grid on Return of Content

			var content = "";

			data = {};

			data.action = 'revslider_ajax_call_front';
			data.client_action = 'get_slider_html';
			data.token = '0d8f482790';
			data.type = obj.type;
			data.id = obj.id;
			data.aspectratio = obj.aspectratio;

			// SYNC AJAX REQUEST
			jQuery.ajax({
				type: "post",
				url: "#",
				dataType: 'json',
				data: data,
				async: false,
				success: function(ret, textStatus, XMLHttpRequest) {
					if (ret.success == true)
						content = ret.data;
				},
				error: function(e) {
					console.log(e);
				}
			});

			// FIRST RETURN THE CONTENT WHEN IT IS LOADED !!
			return content;
		};

		// CUSTOM AJAX FUNCTION TO REMOVE THE SLIDER
		var ajaxRemoveRevslider = function(obj) {
			return jQuery(obj.selector + " .rev_slider").revkill();
		};

		// EXTEND THE AJAX CONTENT LOADING TYPES WITH TYPE AND FUNCTION
		var extendessential = setInterval(function() {
			if (jQuery.fn.tpessential != undefined) {
				clearInterval(extendessential);
				if (typeof(jQuery.fn.tpessential.defaults) !== 'undefined') {
					jQuery.fn.tpessential.defaults.ajaxTypes.push({
						type: "revslider",
						func: ajaxRevslider,
						killfunc: ajaxRemoveRevslider,
						openAnimationSpeed: 0.3
					});
					// type:  Name of the Post to load via Ajax into the Essential Grid Ajax Container
					// func: the Function Name which is Called once the Item with the Post Type has been clicked
					// killfunc: function to kill in case the Ajax Window going to be removed (before Remove function !
					// openAnimationSpeed: how quick the Ajax Content window should be animated (default is 0.3)
				}
			}
		}, 30);
	});

// js after footer block
	(function() {
		function addEventListener(element, event, handler) {
			if (element.addEventListener) {
				element.addEventListener(event, handler, false);
			} else if (element.attachEvent) {
				element.attachEvent('on' + event, handler);
			}
		}

		function maybePrefixUrlField() {
			if (this.value.trim() !== '' && this.value.indexOf('http') !== 0) {
				this.value = "http://" + this.value;
			}
		}

		var urlFields = document.querySelectorAll('.mc4wp-form input[type="url"]');
		if (urlFields && urlFields.length > 0) {
			for (var j = 0; j < urlFields.length; j++) {
				addEventListener(urlFields[j], 'blur', maybePrefixUrlField);
			}
		} /* test if browser supports date fields */
		var testInput = document.createElement('input');
		testInput.setAttribute('type', 'date');
		if (testInput.type !== 'date') {

			/* add placeholder & pattern to all date fields */
			var dateFields = document.querySelectorAll('.mc4wp-form input[type="date"]');
			for (var i = 0; i < dateFields.length; i++) {
				if (!dateFields[i].placeholder) {
					dateFields[i].placeholder = 'YYYY-MM-DD';
				}
				if (!dateFields[i].pattern) {
					dateFields[i].pattern = '[0-9]{4}-(0[1-9]|1[012])-(0[1-9]|1[0-9]|2[0-9]|3[01])';
				}
			}
		}

	})();
	var woocommerce_price_slider_params = {"currency_symbol":"$","currency_pos":"left","min_price":"","max_price":""};
	/* <![CDATA[ */
	var tribe_js_config = {"permalink_settings":"\/%postname%\/","events_post_type":"tribe_events","events_base":"events.html"};
	/* ]]> */
